import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path:'library',
    loadChildren:'./library/library.module#LibraryModule'
  },
  {
    path:'cafeteria',
    loadChildren:'./cafeteria/cafeteria.module#CafeteriaModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
