import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddMealComponent } from './add-meal/add-meal.component';
import { DeleteMealComponent } from './delete-meal/delete-meal.component';

const routes: Routes = [
  {
    path:'addMeal',
    component:AddMealComponent
  },
  {
    path:'deleteMeal',
    component:DeleteMealComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CafeteriaRoutingModule { }
