import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CafeteriaRoutingModule } from './cafeteria-routing.module';
import { AddMealComponent } from './add-meal/add-meal.component';
import { DeleteMealComponent } from './delete-meal/delete-meal.component';

@NgModule({
  imports: [
    CommonModule,
    CafeteriaRoutingModule
  ],
  declarations: [AddMealComponent, DeleteMealComponent]
})
export class CafeteriaModule { }
