import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { FrontpageComponent } from './frontpage/frontpage.component';
import { OpmenuComponent } from './library/opmenu/opmenu.component';

const routes: Routes = [
  {
    path:'',
    component:FrontpageComponent
  },
  {
    path:'library',
    loadChildren:'./library/library.module#LibraryModule'
  },
  {
    path:'cafeteria',
    loadChildren:'./cafeteria/cafeteria.module#CafeteriaModule'
  },
  
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
