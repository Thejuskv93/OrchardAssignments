export class Book
{
    book_name:string;
    author:string;
}