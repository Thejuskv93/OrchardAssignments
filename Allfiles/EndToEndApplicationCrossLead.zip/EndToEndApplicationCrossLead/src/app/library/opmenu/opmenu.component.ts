import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-opmenu',
  templateUrl: './opmenu.component.html',
  styleUrls: ['./opmenu.component.css']
})
export class OpmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
