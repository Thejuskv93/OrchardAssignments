import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {MatButtonModule} from '@angular/material/button';
import { LibraryRoutingModule } from './library-routing.module';
import { AddBookComponent } from './add-book/add-book.component';
import { DeleteBookComponent } from './delete-book/delete-book.component';
import { OpmenuComponent } from './opmenu/opmenu.component';
import {MatCheckboxModule} from '@angular/material/checkbox';

@NgModule({
  imports: [
    CommonModule,
    LibraryRoutingModule,
    MatButtonModule,
    MatCheckboxModule
  ],
  declarations: [AddBookComponent, DeleteBookComponent, OpmenuComponent]
})
export class LibraryModule { }
