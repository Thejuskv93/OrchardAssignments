import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddBookComponent } from './add-book/add-book.component';
import { DeleteBookComponent } from './delete-book/delete-book.component';
import { OpmenuComponent } from './opmenu/opmenu.component';
import { FrontpageComponent } from '../frontpage/frontpage.component';

const routes: Routes = [
  {
    path:'menu',
    component:OpmenuComponent
  },
  {
    path:'addBook',
    component:AddBookComponent
  },
  {
    path:'deleteBook',
    component:DeleteBookComponent
  },
  
  {
    path:'',
    component:'../app.module#AppModule'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LibraryRoutingModule { }
