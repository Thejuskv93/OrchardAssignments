import { Component, OnInit } from '@angular/core';
import { BookService } from '../../book.service';
import swal from 'sweetalert2';
@Component({
  selector: 'app-delete-book',
  templateUrl: './delete-book.component.html',
  styleUrls: ['./delete-book.component.css']
})
export class DeleteBookComponent implements OnInit {
  public bookList=[];
  public delList=[];
  public res:any;
  constructor(private book:BookService) { }
  
  ngOnInit() {
    this.book.getBooks().subscribe(data =>  this.bookList = data);
  }

  isChecked(event,book)
  {
    if(event.target.checked)
    {
      this.delList.push(book);
    }
    else{
      this.delList.splice(book);
    }
  }
  deleteBook()
  {
    console.log(this.delList);
    this.book.delBooks(this.delList).subscribe(data => {
      this.res=data;
      if(this.res==true)
      {
        swal(
          'Done',
          'Your data has been deleted succesfully!',
          'success'
        )
        window.location.reload();
      }
    });
  }
}
