import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Book } from './book';

@Injectable()
export class BookService {
public add_url="http://localhost:8081/CrossLeadProgram/library/addBooks";
public get_url="http://localhost:8081/CrossLeadProgram/library/getBooks";
public del_url="http://localhost:8081/CrossLeadProgram/library/deleteBooks";
  constructor(private http:HttpClient) { }

  addBookServ(book)
  {
    console.log(book.author);
    console.log(book.book_name);
    return this.http.post(this.add_url,book);
  }
getBooks():Observable<Book[]>
{
  return this.http.get<Book[]>(this.get_url);
}
delBooks(blist)
{
  return this.http.post(this.del_url,blist);
}

}
