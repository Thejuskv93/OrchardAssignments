import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-meal',
  templateUrl: './delete-meal.component.html',
  styleUrls: ['./delete-meal.component.css']
})
export class DeleteMealComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
