import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cafeteria-menu',
  templateUrl: './cafeteria-menu.component.html',
  styleUrls: ['./cafeteria-menu.component.css']
})
export class CafeteriaMenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
