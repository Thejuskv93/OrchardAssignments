import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CafeteriaMenuComponent } from './cafeteria-menu.component';

describe('CafeteriaMenuComponent', () => {
  let component: CafeteriaMenuComponent;
  let fixture: ComponentFixture<CafeteriaMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CafeteriaMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CafeteriaMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
