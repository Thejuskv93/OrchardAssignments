import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CafeteriaRoutingModule } from './cafeteria-routing.module';
import { AddMealComponent } from './add-meal/add-meal.component';
import { DeleteMealComponent } from './delete-meal/delete-meal.component';
import { CafeteriaMenuComponent } from './cafeteria-menu/cafeteria-menu.component';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  imports: [
    CommonModule,
    CafeteriaRoutingModule,
    MatButtonModule
  ],
  declarations: [AddMealComponent, DeleteMealComponent, CafeteriaMenuComponent]
})
export class CafeteriaModule { }
