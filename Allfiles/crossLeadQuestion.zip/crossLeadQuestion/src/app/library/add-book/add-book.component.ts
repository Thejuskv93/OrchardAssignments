import { Component, OnInit } from '@angular/core';
import { Book } from '../../book';
import { BookService } from '../../book.service';
import swal from 'sweetalert2';

@Component({
  selector: 'app-add-book',
  templateUrl: './add-book.component.html',
  styleUrls: ['./add-book.component.css']
})
export class AddBookComponent implements OnInit {
public book=new Book();
public res:any;
  constructor(private bk:BookService) { }

  ngOnInit() {
  }

  addBook(bookname,author)
  {
    this.book.book_name=bookname;
    this.book.author=author;
    if(bookname!="" && author!="")
    {
      this.bk.addBookServ(this.book).subscribe(data=>{this.res=data;
        if(this.res==true)
        {
          swal(
            'Done',
            'Your data has been added succesfully!',
            'success'
          )
        }
        });
      }
      else{
        alert('You must insert data')
      }
    }
}
